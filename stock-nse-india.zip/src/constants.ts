export const API_RESPONSE_VALIDATION='API Response Validation'
export const IS_TYPE_STRICT=false
