"use strict";
const app = require("../../server/server");
const loopback = require("loopback");
module.exports = function (Tduser) {};
