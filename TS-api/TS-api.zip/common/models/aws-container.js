'use strict';

module.exports = function(Awscontainer) {

};
